package pl.edu.vistula.first_project_java_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstProjectJavaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstProjectJavaSpringApplication.class, args);
	}

}
