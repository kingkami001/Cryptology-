package com.springstarter.first_rest_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstRestApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
